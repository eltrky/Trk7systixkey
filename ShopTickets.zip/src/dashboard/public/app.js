const productsContainer = document.getElementById('products-container');
const paymentsContainer = document.getElementById('payments-container');
const addProductBtn = document.getElementById('add-product-btn');
const addPaymentBtn = document.getElementById('add-payment-btn');
const configForm = document.getElementById('config-form');
const toast = document.getElementById('toast');
const restoreDbInput = document.getElementById('restore-db-input');
const restoreConfigInput = document.getElementById('restore-config-input');

let allClosedTickets = [];

const showToast = (message) => {
  toast.innerHTML = `<i class="fa-solid fa-circle-check"></i> ${message}`;
  toast.classList.add('show');
  setTimeout(() => {
    toast.classList.remove('show');
  }, 3000);
};

const createProductRow = (name = '', categoryId = '', emoji = '') => {
  const row = document.createElement('div');
  row.className = 'item-row';
  row.innerHTML = `
    <div class="form-group">
      <label>اسم المنتج</label>
      <div class="input-wrapper">
        <i class="fa-solid fa-box"></i>
        <input type="text" class="prod-name" value="${name}" required>
      </div>
    </div>
    <div class="form-group">
      <label>معرف القسم (Category ID)</label>
      <div class="input-wrapper">
        <i class="fa-solid fa-folder"></i>
        <input type="text" class="prod-category" value="${categoryId}" required>
      </div>
    </div>
    <div class="form-group">
      <label>إيموجي المنتج (Emoji ID/Char)</label>
      <div class="input-wrapper">
        <i class="fa-solid fa-face-smile"></i>
        <input type="text" class="prod-emoji" value="${emoji}" required>
      </div>
    </div>
    <button type="button" class="btn btn-danger remove-btn"><i class="fa-solid fa-trash"></i></button>
  `;
  row.querySelector('.remove-btn').addEventListener('click', () => row.remove());
  return row;
};

const createPaymentRow = (name = '', emoji = '') => {
  const row = document.createElement('div');
  row.className = 'item-row payment-row';
  row.innerHTML = `
    <div class="form-group">
      <label>اسم طريقة الدفع</label>
      <div class="input-wrapper">
        <i class="fa-solid fa-wallet"></i>
        <input type="text" class="pay-name" value="${name}" required>
      </div>
    </div>
    <div class="form-group">
      <label>إيموجي الدفع (Emoji ID/Char)</label>
      <div class="input-wrapper">
        <i class="fa-solid fa-face-smile"></i>
        <input type="text" class="pay-emoji" value="${emoji}" required>
      </div>
    </div>
    <button type="button" class="btn btn-danger remove-btn"><i class="fa-solid fa-trash"></i></button>
  `;
  row.querySelector('.remove-btn').addEventListener('click', () => row.remove());
  return row;
};

addProductBtn.addEventListener('click', () => {
  productsContainer.appendChild(createProductRow());
});

addPaymentBtn.addEventListener('click', () => {
  paymentsContainer.appendChild(createPaymentRow());
});

const populateRoles = async (config) => {
  try {
    const res = await fetch('/api/roles');
    const roles = await res.json();

    const sellerSelect = document.getElementById('sellerRoleId');
    const blacklistSelect = document.getElementById('blacklistRoleId');
    const clientSelect = document.getElementById('clientRoleId');

    sellerSelect.innerHTML = '';
    blacklistSelect.innerHTML = '';
    clientSelect.innerHTML = '';

    if (roles.length === 0) {
      const sellerOpt = document.createElement('option');
      sellerOpt.value = config.sellerRoleId || '';
      sellerOpt.textContent = config.sellerRoleId || 'غير محدد';
      sellerSelect.appendChild(sellerOpt);

      const blacklistOpt = document.createElement('option');
      blacklistOpt.value = config.blacklistRoleId || '';
      blacklistOpt.textContent = config.blacklistRoleId || 'غير محدد';
      blacklistSelect.appendChild(blacklistOpt);

      const clientOpt = document.createElement('option');
      clientOpt.value = config.clientRoleId || '';
      clientOpt.textContent = config.clientRoleId || 'غير محدد';
      clientSelect.appendChild(clientOpt);
      return;
    }

    roles.forEach(role => {
      const opt1 = document.createElement('option');
      opt1.value = role.id;
      opt1.textContent = role.name;
      sellerSelect.appendChild(opt1);

      const opt2 = document.createElement('option');
      opt2.value = role.id;
      opt2.textContent = role.name;
      blacklistSelect.appendChild(opt2);

      const opt3 = document.createElement('option');
      opt3.value = role.id;
      opt3.textContent = role.name;
      clientSelect.appendChild(opt3);
    });

    if (config.sellerRoleId) {
      if (![...sellerSelect.options].some(o => o.value === config.sellerRoleId)) {
        const opt = document.createElement('option');
        opt.value = config.sellerRoleId;
        opt.textContent = `دور مخصص (${config.sellerRoleId})`;
        sellerSelect.appendChild(opt);
      }
      sellerSelect.value = config.sellerRoleId;
    }

    if (config.blacklistRoleId) {
      if (![...blacklistSelect.options].some(o => o.value === config.blacklistRoleId)) {
        const opt = document.createElement('option');
        opt.value = config.blacklistRoleId;
        opt.textContent = `دور مخصص (${config.blacklistRoleId})`;
        blacklistSelect.appendChild(opt);
      }
      blacklistSelect.value = config.blacklistRoleId;
    }

    if (config.clientRoleId) {
      if (![...clientSelect.options].some(o => o.value === config.clientRoleId)) {
        const opt = document.createElement('option');
        opt.value = config.clientRoleId;
        opt.textContent = `دور مخصص (${config.clientRoleId})`;
        clientSelect.appendChild(opt);
      }
      clientSelect.value = config.clientRoleId;
    } else {
      clientSelect.value = '';
    }
  } catch (e) {
    console.error(e);
  }
};

const populateChannels = async (config) => {
  try {
    const res = await fetch('/api/channels');
    const channels = await res.json();

    const logSelect = document.getElementById('logChannelId');
    const feedbackSelect = document.getElementById('feedbackChannelId');

    logSelect.innerHTML = '';
    feedbackSelect.innerHTML = '';

    if (channels.length === 0) {
      const logOpt = document.createElement('option');
      logOpt.value = config.logChannelId || '';
      logOpt.textContent = config.logChannelId || 'غير محدد';
      logSelect.appendChild(logOpt);

      const feedbackOpt = document.createElement('option');
      feedbackOpt.value = config.feedbackChannelId || '';
      feedbackOpt.textContent = config.feedbackChannelId || 'غير محدد';
      feedbackSelect.appendChild(feedbackOpt);
      return;
    }

    channels.forEach(channel => {
      const opt1 = document.createElement('option');
      opt1.value = channel.id;
      opt1.textContent = `# ${channel.name}`;
      logSelect.appendChild(opt1);

      const opt2 = document.createElement('option');
      opt2.value = channel.id;
      opt2.textContent = `# ${channel.name}`;
      feedbackSelect.appendChild(opt2);
    });

    if (config.logChannelId) {
      if (![...logSelect.options].some(o => o.value === config.logChannelId)) {
        const opt = document.createElement('option');
        opt.value = config.logChannelId;
        opt.textContent = `# قناة مخصصة (${config.logChannelId})`;
        logSelect.appendChild(opt);
      }
      logSelect.value = config.logChannelId;
    }

    if (config.feedbackChannelId) {
      if (![...feedbackSelect.options].some(o => o.value === config.feedbackChannelId)) {
        const opt = document.createElement('option');
        opt.value = config.feedbackChannelId;
        opt.textContent = `# قناة مخصصة (${config.feedbackChannelId})`;
        feedbackSelect.appendChild(opt);
      }
      feedbackSelect.value = config.feedbackChannelId;
    }
  } catch (e) {
    console.error(e);
  }
};

const updateWelcomePreview = () => {
  const bannerUrl = document.getElementById('bannerUrl').value;
  const welcomeTitle = document.getElementById('welcomeTitle').value || 'Order - #0001';
  const welcomeText = document.getElementById('welcomeText').value || 'مرحبا بك @user';

  const bannerImg = document.getElementById('mock-banner');
  if (bannerUrl) {
    bannerImg.src = bannerUrl;
    bannerImg.style.display = 'block';
  } else {
    bannerImg.style.display = 'none';
  }

  const titleText = welcomeTitle.replace('{ticketNum}', '0001');
  document.getElementById('mock-title').textContent = `# ${titleText}`;

  const descHtml = welcomeText
    .replace('{user}', '<span style="background: rgba(88, 101, 242, 0.15); color: #c9cdfb; padding: 0 4px; border-radius: 3px; font-weight: 600; font-family: \'Almarai\', sans-serif;">@enzo</span>');
  document.getElementById('mock-description').innerHTML = descHtml;
};

const loadConfig = async () => {
  try {
    const res = await fetch('/api/config');
    const config = await res.json();

    document.getElementById('token').value = config.token || '';
    document.getElementById('clientId').value = config.clientId || '';
    document.getElementById('guildId').value = config.guildId || '';
    document.getElementById('bannerUrl').value = config.bannerUrl || '';
    document.getElementById('language').value = config.language || 'ar';
    document.getElementById('welcomeTitle').value = config.welcomeTitle || 'Order - #{ticketNum}';
    document.getElementById('welcomeText').value = config.welcomeText || 'مرحبا بك {user}';

    await populateRoles(config);
    await populateChannels(config);
    updateWelcomePreview();

    productsContainer.innerHTML = '';
    if (config.products && Array.isArray(config.products)) {
      config.products.forEach(p => {
        productsContainer.appendChild(createProductRow(p.name, p.categoryId, p.emoji));
      });
    }

    paymentsContainer.innerHTML = '';
    if (config.payments && Array.isArray(config.payments)) {
      config.payments.forEach(p => {
        paymentsContainer.appendChild(createPaymentRow(p.name, p.emoji));
      });
    }
  } catch (error) {
    showToast('خطأ أثناء تحميل الإعدادات!');
  }
};

configForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const prodNames = document.querySelectorAll('.prod-name');
  const prodCategories = document.querySelectorAll('.prod-category');
  const prodEmojis = document.querySelectorAll('.prod-emoji');

  const products = [];
  prodNames.forEach((input, index) => {
    products.push({
      name: input.value,
      categoryId: prodCategories[index].value,
      emoji: prodEmojis[index].value
    });
  });

  const payNames = document.querySelectorAll('.pay-name');
  const payEmojis = document.querySelectorAll('.pay-emoji');

  const payments = [];
  payNames.forEach((input, index) => {
    payments.push({
      name: input.value,
      emoji: payEmojis[index].value
    });
  });

  const payload = {
    token: document.getElementById('token').value,
    clientId: document.getElementById('clientId').value,
    guildId: document.getElementById('guildId').value,
    bannerUrl: document.getElementById('bannerUrl').value,
    sellerRoleId: document.getElementById('sellerRoleId').value,
    logChannelId: document.getElementById('logChannelId').value,
    feedbackChannelId: document.getElementById('feedbackChannelId').value,
    blacklistRoleId: document.getElementById('blacklistRoleId').value,
    clientRoleId: document.getElementById('clientRoleId').value,
    language: document.getElementById('language').value,
    welcomeTitle: document.getElementById('welcomeTitle').value,
    welcomeText: document.getElementById('welcomeText').value,
    products,
    payments
  };

  try {
    const res = await fetch('/api/config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });
    const result = await res.json();
    if (result.success) {
      showToast('تم حفظ وتطبيق الإعدادات بنجاح! 🎉');
    } else {
      showToast('فشل حفظ الإعدادات!');
    }
  } catch (error) {
    showToast('حدث خطأ أثناء إرسال البيانات!');
  }
});

const updateMetrics = async () => {
  try {
    const res = await fetch('/api/status');
    const status = await res.json();

    const botStatusEl = document.getElementById('bot-status');
    const botPingEl = document.getElementById('bot-ping');
    const botTicketsEl = document.getElementById('bot-tickets');
    const botMetricsEl = document.getElementById('bot-metrics');
    const avatarImg = document.getElementById('bot-avatar-img');
    const brandStatus = document.getElementById('brand-status');
    const navPing = document.getElementById('nav-ping');
    const navUptime = document.getElementById('nav-uptime');

    if (status.botAvatar) {
      avatarImg.src = status.botAvatar;
      avatarImg.style.display = 'block';
    } else {
      avatarImg.style.display = 'none';
    }

    if (status.botName && status.botName !== 'Offline') {
      botStatusEl.innerHTML = `<span style="color:#10b981"><i class="fa-solid fa-circle-play"></i> متصل</span><br><span style="font-size:0.85rem;color:var(--text-muted);word-break:break-all;">${status.botName}</span>`;
      brandStatus.innerHTML = `<i class="fa-solid fa-circle-dot" style="color:#10b981;animation:pulse 2s infinite"></i> ${status.botName}`;
    } else {
      botStatusEl.innerHTML = `<span style="color:#ef4444"><i class="fa-solid fa-circle-stop"></i> غير متصل</span>`;
      brandStatus.innerHTML = `<i class="fa-solid fa-circle-dot" style="color:#ef4444"></i> غير متصل`;
    }

    botPingEl.textContent = `${status.ping} ms`;
    if (navPing) navPing.textContent = `${status.ping} ms`;
    botTicketsEl.textContent = status.activeTickets;

    const days = Math.floor(status.uptime / (3600 * 24));
    const hours = Math.floor((status.uptime % (3600 * 24)) / 3600);
    const mins = Math.floor((status.uptime % 3600) / 60);
    const uptimeStr = days > 0 ? `${days}d ${hours}h` : `${hours}h ${mins}m`;

    botMetricsEl.innerHTML = `${status.memoryUsage}<br><span style="font-size:0.85rem;color:var(--text-muted)"><i class="fa-solid fa-clock"></i> ${uptimeStr}</span>`;
    if (navUptime) navUptime.textContent = uptimeStr;
  } catch (error) {
    document.getElementById('bot-status').innerHTML = `<span style="color:#ef4444"><i class="fa-solid fa-circle-exclamation"></i> خطأ بالاتصال</span>`;
  }
};

let myChart = null;
const renderChart = (stats) => {
  const canvas = document.getElementById('analytics-chart');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (myChart) myChart.destroy();

  const labels = stats.map(s => s.claimedBy);
  const claimsData = stats.map(s => s.totalClaims);
  const ratingsData = stats.map(s => s.avgRating || 0);

  myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [
        {
          label: 'التذاكر المستلمة (Claims)',
          data: claimsData,
          backgroundColor: 'rgba(139, 92, 246, 0.4)',
          borderColor: '#8b5cf6',
          borderWidth: 2,
          borderRadius: 6,
          yAxisID: 'y'
        },
        {
          label: 'متوسط التقييم (Avg Rating)',
          data: ratingsData,
          type: 'line',
          borderColor: '#f59e0b',
          backgroundColor: 'transparent',
          borderWidth: 3,
          pointBackgroundColor: '#f59e0b',
          pointRadius: 5,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: '#64748b',
            font: { family: 'Almarai' }
          }
        }
      },
      scales: {
        x: {
          grid: { color: 'rgba(255, 255, 255, 0.02)' },
          ticks: {
            color: '#64748b',
            font: { family: 'Almarai' }
          }
        },
        y: {
          position: 'right',
          grid: { color: 'rgba(255, 255, 255, 0.02)' },
          ticks: {
            color: '#64748b',
            font: { family: 'Almarai' }
          },
          title: {
            display: true,
            text: 'عدد التذاكر',
            color: '#64748b',
            font: { family: 'Almarai' }
          }
        },
        y1: {
          position: 'left',
          grid: { display: false },
          ticks: {
            color: '#eab308',
            font: { family: 'Almarai' },
            min: 0,
            max: 5
          },
          title: {
            display: true,
            text: 'التقييم (النجوم)',
            color: '#eab308',
            font: { family: 'Almarai' }
          }
        }
      }
    }
  });
};

const updateAnalytics = async () => {
  try {
    const res = await fetch('/api/analytics');
    const stats = await res.json();

    const tbody = document.getElementById('leaderboard-body');
    if (!stats || stats.length === 0) {
      tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--text-muted);">لا توجد تحليلات مسجلة حالياً..</td></tr>`;
      return;
    }

    tbody.innerHTML = '';
    stats.forEach(row => {
      const respSeconds = Math.round(row.avgResponseTime) || 0;
      let respStr = 'فوري';
      if (respSeconds > 0) {
        const mins = Math.floor(respSeconds / 60);
        const secs = respSeconds % 60;
        respStr = mins > 0 ? `${mins}د ${secs}ث` : `${secs}ث`;
      }

      const ratingNum = row.avgRating ? Number(row.avgRating).toFixed(1) : 'N/A';
      const ratingStr = row.avgRating ? `⭐ ${ratingNum}` : 'بدون تقييم';

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><span style="font-family:'Inter'"><i class="fa-solid fa-user"></i> ${row.claimedBy}</span></td>
        <td><strong style="color:#ffffff">${row.totalClaims}</strong></td>
        <td><span style="color:#ffffff">${respStr}</span></td>
        <td><span style="color:#eab308">${ratingStr}</span></td>
      `;
      tbody.appendChild(tr);
    });

    renderChart(stats);
  } catch (error) {
    console.error(error);
  }
};

restoreDbInput.addEventListener('change', async () => {
  if (restoreDbInput.files.length === 0) return;
  const file = restoreDbInput.files[0];
  const formData = new FormData();
  formData.append('database', file);

  try {
    const res = await fetch('/api/restore/database', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();
    if (result.success) {
      showToast('تم استعادة قاعدة البيانات بنجاح! 💾');
      updateMetrics();
      updateAnalytics();
    } else {
      showToast('فشل استعادة قاعدة البيانات!');
    }
  } catch (e) {
    showToast('خطأ أثناء رفع الملف!');
  }
});

restoreConfigInput.addEventListener('change', async () => {
  if (restoreConfigInput.files.length === 0) return;
  const file = restoreConfigInput.files[0];
  const formData = new FormData();
  formData.append('config', file);

  try {
    const res = await fetch('/api/restore/config', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();
    if (result.success) {
      showToast('تم استعادة ملف الإعدادات بنجاح! ⚙️');
      loadConfig();
    } else {
      showToast('فشل استعادة ملف الإعدادات!');
    }
  } catch (e) {
    showToast('خطأ أثناء رفع الملف!');
  }
});

const updateArchive = async () => {
  try {
    const res = await fetch('/api/archive');
    const archive = await res.json();
    allClosedTickets = archive || [];
    const tbody = document.getElementById('archive-body');
    if (!archive || archive.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--text-muted);">لا توجد تذاكر مغلقة في الأرشيف حالياً..</td></tr>`;
      updateFeedbackQA();
      return;
    }

    tbody.innerHTML = '';
    archive.forEach(row => {
      const closedDate = new Date(row.closedAt * 1000).toLocaleString('ar-EG', { hour12: true });
      const ratingVal = row.stars ? `⭐ ${row.stars}` : 'بدون تقييم';
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong style="color:#ffffff">#${row.ticketNum}</strong></td>
        <td><span style="font-family:'Inter'">${row.openerId}</span></td>
        <td><span>${row.product}</span></td>
        <td><span>${row.payment}</span></td>
        <td><span style="font-family:'Inter'">${row.claimedBy || 'غير مستلمة'}</span></td>
        <td><span style="color:#eab308">${ratingVal}</span></td>
        <td><span style="font-size:0.9rem; color:var(--text-muted)">${closedDate}</span></td>
      `;
      tbody.appendChild(tr);
    });

    updateFeedbackQA();
  } catch (e) {
    console.error(e);
  }
};

const updateLogs = async () => {
  try {
    const res = await fetch('/api/logs');
    const logs = await res.json();
    const consoleEl = document.getElementById('live-console');
    if (consoleEl && logs.length > 0) {
      consoleEl.textContent = logs.join('\n');
      consoleEl.scrollTop = consoleEl.scrollHeight;
    }
  } catch (e) {
    console.error(e);
  }
};

const updateFeedbackQA = () => {
  const tbody = document.getElementById('feedback-qa-body');
  if (!tbody) return;

  const filter = document.getElementById('feedback-filter-select').value;
  
  let filtered = allClosedTickets;
  if (filter === 'excellent') {
    filtered = allClosedTickets.filter(t => t.stars >= 4);
  } else if (filter === 'average') {
    filtered = allClosedTickets.filter(t => t.stars === 3);
  } else if (filter === 'poor') {
    filtered = allClosedTickets.filter(t => t.stars >= 1 && t.stars <= 2);
  } else if (filter === 'unrated') {
    filtered = allClosedTickets.filter(t => t.stars === null);
  }

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">لا توجد تقييمات مطابقة للتصفية المحددة..</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  filtered.forEach(row => {
    let ratingStars = '';
    if (row.stars) {
      for (let i = 0; i < row.stars; i++) {
        ratingStars += '<i class="fa-solid fa-star" style="color:#eab308; margin-right:2px;"></i>';
      }
    } else {
      ratingStars = '<span style="color:var(--text-muted)">غير مقيم</span>';
    }

    const respSeconds = (row.claimedAt && row.createdAt) ? (row.claimedAt - row.createdAt) : 0;
    let respStr = 'فوري';
    if (respSeconds > 0) {
      const mins = Math.floor(respSeconds / 60);
      const secs = respSeconds % 60;
      respStr = mins > 0 ? `${mins}د ${secs}ث` : `${secs}ث`;
    }

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong style="color:#ffffff">#${row.ticketNum}</strong></td>
      <td><span style="font-family:'Inter'">${row.openerId}</span></td>
      <td><span>${row.product}</span></td>
      <td><span style="font-family:'Inter'">${row.claimedBy || 'غير مستلمة'}</span></td>
      <td><span style="color:#ffffff">${respStr}</span></td>
      <td><span>${ratingStars}</span></td>
    `;
    tbody.appendChild(tr);
  });
};

const updateBlacklist = async () => {
  try {
    const res = await fetch('/api/blacklist');
    const members = await res.json();
    const tbody = document.getElementById('blacklist-body');
    if (!tbody) return;

    if (!members || members.length === 0) {
      tbody.innerHTML = `<tr><td colspan="3" style="text-align: center; color: var(--text-muted);">لا يوجد أعضاء في قائمة الحظر حالياً..</td></tr>`;
      return;
    }

    tbody.innerHTML = '';
    members.forEach(member => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>
          <div style="display: flex; align-items: center; gap: 12px; text-align: left; direction: ltr;">
            <img src="${member.avatar}" alt="avatar" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1px solid rgba(255,255,255,0.08);">
            <strong style="color: #ffffff; font-family: 'Inter'; font-size: 0.95rem;">${member.username}</strong>
          </div>
        </td>
        <td><span style="font-family: 'Courier New', monospace; font-weight: 600; color: var(--text-muted);">${member.id}</span></td>
        <td>
          <button type="button" class="btn btn-secondary unban-btn" data-id="${member.id}" style="padding: 6px 12px; font-size: 0.8rem; height: auto; width: auto;"><i class="fa-solid fa-user-check" style="color: var(--success-color)"></i> فك الحظر</button>
        </td>
      `;
      
      tr.querySelector('.unban-btn').addEventListener('click', async () => {
        try {
          const postRes = await fetch('/api/blacklist/remove', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userId: member.id })
          });
          const result = await postRes.json();
          if (result.success) {
            showToast('تم إزالة العضو من قائمة الحظر بنجاح! 🔓');
            updateBlacklist();
          } else {
            showToast('فشل فك الحظر عن العضو!');
          }
        } catch (err) {
          showToast('حدث خطأ أثناء الاتصال بالخادم!');
        }
      });

      tbody.appendChild(tr);
    });
  } catch (e) {
    console.error(e);
  }
};

const blacklistForm = document.getElementById('blacklist-add-form');
if (blacklistForm) {
  blacklistForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userIdInput = document.getElementById('blacklist-user-id');
    const userId = userIdInput.value.trim();
    if (!userId) return;

    try {
      const postRes = await fetch('/api/blacklist/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId })
      });
      const result = await postRes.json();
      if (result.success) {
        showToast('تم حظر العضو وإضافته للبلاك ليست بنجاح! 🔒');
        userIdInput.value = '';
        updateBlacklist();
      } else {
        showToast(result.error || 'فشل حظر العضو! تأكد من صحة الـ ID ووجوده بالسيرفر.');
      }
    } catch (err) {
      showToast('حدث خطأ أثناء الاتصال بالخادم!');
    }
  });
}

const tabs = document.querySelectorAll('.sidebar-tab');
const contents = document.querySelectorAll('.tab-content');
tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    tabs.forEach(t => t.classList.remove('active'));
    contents.forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    const target = document.getElementById(tab.dataset.target);
    if (target) {
      target.classList.add('active');
      if (tab.dataset.target === 'archive-tab') {
        updateArchive();
      } else if (tab.dataset.target === 'feedback-qa-tab') {
        updateFeedbackQA();
      } else if (tab.dataset.target === 'blacklist-tab') {
        updateBlacklist();
      }
    }
  });
});

document.getElementById('welcomeTitle').addEventListener('input', updateWelcomePreview);
document.getElementById('welcomeText').addEventListener('input', updateWelcomePreview);
document.getElementById('bannerUrl').addEventListener('input', updateWelcomePreview);
document.getElementById('feedback-filter-select').addEventListener('change', updateFeedbackQA);

loadConfig();
updateMetrics();
updateAnalytics();
updateArchive();
updateLogs();
updateBlacklist();
setInterval(updateMetrics, 5000);
setInterval(updateAnalytics, 10000);
setInterval(updateArchive, 10000);
setInterval(updateLogs, 3000);
setInterval(updateBlacklist, 15000);
