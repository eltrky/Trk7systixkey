const express = require('express');
const path = require('path');
const multer = require('multer');
const fs = require('fs');
const { getConfig, saveConfig, loadConfig } = require('../utils/configStore');
const { get, all } = require('../utils/db');

const logBuffer = [];
const originalLog = console.log;
console.log = function (...args) {
  originalLog.apply(console, args);
  const time = new Date().toLocaleTimeString('en-US', { hour12: false });
  const msg = args.map(arg => typeof arg === 'object' ? JSON.stringify(arg) : arg).join(' ');
  logBuffer.push(`[${time}] ${msg}`);
  if (logBuffer.length > 80) logBuffer.shift();
};

const app = express();
let PORT = 3000;
const portFilePath = path.join(__dirname, '../../port');
if (fs.existsSync(portFilePath)) {
  try {
    const data = fs.readFileSync(portFilePath, 'utf8').trim();
    const parsed = parseInt(data, 10);
    if (!isNaN(parsed) && parsed > 0) {
      PORT = parsed;
    }
  } catch (error) {
    console.error(error);
  }
}

let clientInstance = null;

const dbPath = path.join(__dirname, '../../database.sqlite');
const configPath = path.join(__dirname, '../../config.json');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../../'));
  },
  filename: (req, file, cb) => {
    if (file.fieldname === 'database') cb(null, 'database.sqlite');
    else if (file.fieldname === 'config') cb(null, 'config.json');
    else cb(null, file.originalname);
  }
});

const upload = multer({ storage });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/config', (req, res) => {
  res.json(getConfig());
});

app.post('/api/config', (req, res) => {
  const success = saveConfig(req.body);
  if (success) {
    res.json({ success: true });
  } else {
    res.status(500).json({ success: false, error: 'Failed to write config file' });
  }
});

app.get('/api/status', async (req, res) => {
  try {
    const activeTicketsRow = await get('SELECT COUNT(*) AS count FROM tickets');
    const activeTickets = activeTicketsRow ? activeTicketsRow.count : 0;

    res.json({
      botName: clientInstance && clientInstance.user ? clientInstance.user.tag : 'Offline',
      botAvatar: clientInstance && clientInstance.user ? clientInstance.user.displayAvatarURL({ extension: 'png', size: 128 }) : '',
      guildsCount: clientInstance ? clientInstance.guilds.cache.size : 0,
      ping: clientInstance ? Math.round(clientInstance.ws.ping) : 0,
      activeTickets: activeTickets,
      memoryUsage: Math.round(process.memoryUsage().heapUsed / 1024 / 1024) + ' MB',
      uptime: Math.round(process.uptime())
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/analytics', async (req, res) => {
  try {
    const stats = await all(`
      SELECT 
        claimedBy,
        COUNT(*) AS totalClaims,
        AVG(claimedAt - createdAt) AS avgResponseTime,
        AVG(stars) AS avgRating
      FROM closed_tickets 
      WHERE claimedBy IS NOT NULL AND claimedBy != 'Unclaimed'
      GROUP BY claimedBy
      ORDER BY totalClaims DESC
    `);
    res.json(stats || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/roles', async (req, res) => {
  try {
    if (!clientInstance) return res.json([]);
    const { getConfig } = require('../utils/configStore');
    const config = getConfig();
    const guild = clientInstance.guilds.cache.get(config.guildId);
    if (!guild) return res.json([]);
    const roles = guild.roles.cache.map(r => ({ id: r.id, name: r.name }));
    res.json(roles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/channels', async (req, res) => {
  try {
    if (!clientInstance) return res.json([]);
    const { getConfig } = require('../utils/configStore');
    const config = getConfig();
    const guild = clientInstance.guilds.cache.get(config.guildId);
    if (!guild) return res.json([]);
    const channels = guild.channels.cache
      .filter(c => c.type === 0 || c.type === 5)
      .map(c => ({ id: c.id, name: c.name }));
    res.json(channels);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/archive', async (req, res) => {
  try {
    const rows = await all(`
      SELECT 
        channelId, openerId, ticketNum, product, payment, claimedBy, createdAt, claimedAt, closedAt, stars 
      FROM closed_tickets 
      ORDER BY closedAt DESC
    `);
    res.json(rows || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.get('/api/logs', (req, res) => {
  res.json(logBuffer);
});

app.get('/api/blacklist', async (req, res) => {
  try {
    if (!clientInstance) return res.json([]);
    const { getConfig } = require('../utils/configStore');
    const config = getConfig();
    if (!config.blacklistRoleId) return res.json([]);
    const guild = clientInstance.guilds.cache.get(config.guildId);
    if (!guild) return res.json([]);

    const role = await guild.roles.fetch(config.blacklistRoleId);
    if (!role) return res.json([]);

    const members = role.members.map(m => ({
      id: m.user.id,
      username: m.user.tag,
      avatar: m.user.displayAvatarURL({ extension: 'png', size: 128 })
    }));
    res.json(members);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/blacklist/add', async (req, res) => {
  try {
    if (!clientInstance) return res.status(500).json({ success: false, error: 'Bot offline' });
    const { getConfig } = require('../utils/configStore');
    const config = getConfig();
    if (!config.blacklistRoleId) return res.status(400).json({ success: false, error: 'Blacklist role not configured' });
    const guild = clientInstance.guilds.cache.get(config.guildId);
    if (!guild) return res.status(400).json({ success: false, error: 'Guild not found' });

    const { userId } = req.body;
    if (!userId) return res.status(400).json({ success: false, error: 'User ID required' });

    const member = await guild.members.fetch(userId);
    if (!member) return res.status(404).json({ success: false, error: 'Member not found in server' });

    await member.roles.add(config.blacklistRoleId);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post('/api/blacklist/remove', async (req, res) => {
  try {
    if (!clientInstance) return res.status(500).json({ success: false, error: 'Bot offline' });
    const { getConfig } = require('../utils/configStore');
    const config = getConfig();
    if (!config.blacklistRoleId) return res.status(400).json({ success: false, error: 'Blacklist role not configured' });
    const guild = clientInstance.guilds.cache.get(config.guildId);
    if (!guild) return res.status(400).json({ success: false, error: 'Guild not found' });

    const { userId } = req.body;
    if (!userId) return res.status(400).json({ success: false, error: 'User ID required' });

    const member = await guild.members.fetch(userId);
    if (!member) return res.status(404).json({ success: false, error: 'Member not found in server' });

    await member.roles.remove(config.blacklistRoleId);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/backup/database', (req, res) => {
  if (fs.existsSync(dbPath)) {
    res.download(dbPath, 'database.sqlite');
  } else {
    res.status(404).json({ error: 'Database file not found' });
  }
});

app.get('/api/backup/config', (req, res) => {
  if (fs.existsSync(configPath)) {
    res.download(configPath, 'config.json');
  } else {
    res.status(404).json({ error: 'Config file not found' });
  }
});

app.post('/api/restore/database', upload.single('database'), (req, res) => {
  res.json({ success: true });
});

app.post('/api/restore/config', upload.single('config'), (req, res) => {
  loadConfig();
  res.json({ success: true });
});

const startDashboard = (client) => {
  clientInstance = client;
  app.listen(PORT, () => {
    console.log(`Dashboard listening on http://localhost:${PORT}`);
  });
};

module.exports = { startDashboard };
