const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../../database.sqlite');
const db = new sqlite3.Database(dbPath);

const run = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
};

const get = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) reject(err);
      else resolve(row);
    });
  });
};

const all = (sql, params = []) => {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
};

const initDB = async () => {
  await run(`
    CREATE TABLE IF NOT EXISTS counters (
      id TEXT PRIMARY KEY,
      sequence_value INTEGER DEFAULT 0
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS tickets (
      channelId TEXT PRIMARY KEY,
      openerId TEXT,
      ticketNum TEXT,
      product TEXT,
      payment TEXT,
      claimed INTEGER DEFAULT 0,
      claimedBy TEXT DEFAULT NULL,
      createdAt INTEGER DEFAULT 0,
      claimedAt INTEGER DEFAULT NULL
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS closed_tickets (
      channelId TEXT PRIMARY KEY,
      openerId TEXT,
      ticketNum TEXT,
      product TEXT,
      payment TEXT,
      claimedBy TEXT,
      createdAt INTEGER,
      claimedAt INTEGER,
      closedAt INTEGER,
      stars INTEGER DEFAULT NULL
    )
  `);

  try {
    await run(`ALTER TABLE tickets ADD COLUMN createdAt INTEGER DEFAULT 0`);
  } catch (e) {}

  try {
    await run(`ALTER TABLE tickets ADD COLUMN claimedAt INTEGER DEFAULT NULL`);
  } catch (e) {}

  await run(`
    INSERT OR IGNORE INTO counters (id, sequence_value) VALUES ('tickets', 0)
  `);
};

module.exports = { initDB, run, get, all };
