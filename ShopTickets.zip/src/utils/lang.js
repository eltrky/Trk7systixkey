const { getConfig } = require('./configStore');

const translations = {
  ar: {
    loading: '<a:loading:1510598279392399481> **جارِ إنشاء تذكرتك ..**',
    productsPlaceholder: 'الرجاء اختيار منتج',
    categoryNotFound: '<:Warn:1510598267715715102> **لم يتم العثور على القسم المخصص لهذا المنتج.**',
    ticketCreated: '<a:true:1510598263869411439> **تم إنشاء تذكرتك بنجاح!**',
    goToTicket: 'الذهاب إلى التذكرة',
    blacklistWarn: '<:Warn:1510598267715715102> **عذراً، لا يمكنك استخدام نظام التذاكر بسبب وجودك في القائمة السوداء!**',
    noPermission: '<:Warn:1510598267715715102> **عذراً، هذا الإجراء مخصص لموظفي المبيعات فقط!**',
    welcomeUser: 'مرحبا بك <@{user}>',
    orderNum: '# طلب - #{num}',
    productLabel: 'المنتج: {product} | {emoji}',
    paymentLabel: 'طريقة الدفع: {payment} | {emoji}',
    claimLabel: 'استلام',
    unclaimLabel: 'إلغاء الاستلام',
    closeLabel: 'إغلاق',
    configPlaceholder: 'قائمة التحكم بالتذكرة',
    configAdd: 'إضافة عضو',
    configRemove: 'إزالة عضو',
    configRename: 'تغيير اسم القناة',
    configCome: 'استدعاء العميل',
    comeWarn: '<:Warn:1510598267715715102> <@{user}> الرجاء الحضور إلى التذكرة لمتابعة طلبك.',
    comeError: '<:Warn:1510598267715715102> لم يتم العثور على منشئ التذكرة.',
    claimedBy: '<a:true:1510598263869411439> تم استلام التذكرة بواسطة <@{user}>.',
    unclaimedBy: '<:Warn:1510598267715715102> تم إلغاء استلام التذكرة بواسطة <@{user}>.',
    closingTicket: '<:Warn:1510598267715715102> سيتم أرشفة المحادثات وإغلاق التذكرة وحذف القناة خلال 5 ثوانٍ ..',
    ratingSuccess: '<a:true:1510598263869411439> **شكراً لك على تقييمك! تم تسجيل تقييمك بـ {stars} بنجاح.**',
    ratingDM: '## <a:true:1510598263869411439> شكراً لتعاملك معنا!\nلقد تم إغلاق تذكرتك بنجاح.\nالرجاء تقييم تجربتك معنا لشراء **{product}** بالضغط على النجوم أدناه:',
    logEmbedTitle: '📝 أرشيف تذكرة مغلقة',
    logEmbedFields: {
      num: 'رقم التذكرة',
      product: 'المنتج',
      client: 'العميل',
      payment: 'طريقة الدفع',
      claimedBy: 'الموظف المستلم',
      closedBy: 'أغلقت بواسطة',
      claimSpeed: 'سرعة الاستجابة',
      totalDuration: 'العمر الإجمالي للتذكرة',
      closedAt: 'تاريخ الإغلاق'
    },
    feedbackEmbedTitle: '⭐ تقييم جديد للخدمة!',
    feedbackEmbedFields: {
      client: 'العميل',
      product: 'المنتج',
      rating: 'التقييم'
    },
    modalAddTitle: 'إضافة عضو للتذكرة',
    modalAddLabel: 'معرف العضو (User ID)',
    modalAddSuccess: '<a:true:1510598263869411439> تم إضافة العضو <@{user}> بنجاح إلى التذكرة.',
    modalAddError: '<:Warn:1510598267715715102> فشل إضافة العضو. يرجى التأكد من كتابة الـ ID بشكل صحيح.',
    modalRemoveTitle: 'إزالة عضو من التذكرة',
    modalRemoveLabel: 'معرف العضو (User ID)',
    modalRemoveSuccess: '<:Warn:1510598267715715102> تم إزالة العضو <@{user}> من التذكرة.',
    modalRemoveError: '<:Warn:1510598267715715102> فشل إزالة العضو. يرجى التأكد من كتابة الـ ID بشكل صحيح.',
    modalRenameTitle: 'تغيير اسم القناة',
    modalRenameLabel: 'الاسم الجديد (New Name)',
    modalRenameSuccess: '<a:true:1510598263869411439> تم تغيير اسم القناة إلى **{name}** بنجاح.',
    modalRenameError: '<:Warn:1510598267715715102> فشل تغيير اسم القناة. يرجى التحقق من الصلاحيات.'
  },
  en: {
    loading: '<a:loading:1510598279392399481> **Creating your ticket ..**',
    productsPlaceholder: 'Select A Product',
    categoryNotFound: '<:Warn:1510598267715715102> **Product category was not found.**',
    ticketCreated: '<a:true:1510598263869411439> **Ticket created successfully!**',
    goToTicket: 'Go to Ticket',
    blacklistWarn: '<:Warn:1510598267715715102> **Sorry, you are blacklisted from using the ticket system!**',
    noPermission: '<:Warn:1510598267715715102> **Sorry, this action is only for the Sales Team!**',
    welcomeUser: 'Welcome <@{user}>',
    orderNum: '# Order - #{num}',
    productLabel: 'Product: {product} | {emoji}',
    paymentLabel: 'Payment: {payment} | {emoji}',
    claimLabel: 'Claim',
    unclaimLabel: 'Unclaim',
    closeLabel: 'Close',
    configPlaceholder: 'Configuration Menu',
    configAdd: 'Add User',
    configRemove: 'Remove User',
    configRename: 'Rename Channel',
    configCome: 'Summon Client',
    comeWarn: '<:Warn:1510598267715715102> <@{user}> please come to the ticket to continue.',
    comeError: '<:Warn:1510598267715715102> Ticket creator was not found.',
    claimedBy: '<a:true:1510598263869411439> Ticket claimed by <@{user}>.',
    unclaimedBy: '<:Warn:1510598267715715102> Ticket unclaimed by <@{user}>.',
    closingTicket: '<:Warn:1510598267715715102> Archiving chat and closing ticket channel in 5 seconds ..',
    ratingSuccess: '<a:true:1510598263869411439> **Thank you! Your rating of {stars} has been recorded.**',
    ratingDM: '## <a:true:1510598263869411439> Thank you for purchasing!\nYour ticket has been closed.\nPlease rate your experience buying **{product}** below:',
    logEmbedTitle: '📝 Closed Ticket Archive',
    logEmbedFields: {
      num: 'Ticket Number',
      product: 'Product',
      client: 'Client',
      payment: 'Payment',
      claimedBy: 'Claimed By',
      closedBy: 'Closed By',
      claimSpeed: 'Claim Speed',
      totalDuration: 'Total Lifetime',
      closedAt: 'Closed At'
    },
    feedbackEmbedTitle: '⭐ New Service Feedback!',
    feedbackEmbedFields: {
      client: 'Client',
      product: 'Product',
      rating: 'Rating'
    },
    modalAddTitle: 'Add User to Ticket',
    modalAddLabel: 'User ID',
    modalAddSuccess: '<a:true:1510598263869411439> User <@{user}> added successfully to the ticket.',
    modalAddError: '<:Warn:1510598267715715102> Failed to add user. Verify the ID is correct.',
    modalRemoveTitle: 'Remove User from Ticket',
    modalRemoveLabel: 'User ID',
    modalRemoveSuccess: '<:Warn:1510598267715715102> User <@{user}> removed from the ticket.',
    modalRemoveError: '<:Warn:1510598267715715102> Failed to remove user. Verify the ID is correct.',
    modalRenameTitle: 'Rename Channel',
    modalRenameLabel: 'New Name',
    modalRenameSuccess: '<a:true:1510598263869411439> Channel renamed to **{name}** successfully.',
    modalRenameError: '<:Warn:1510598267715715102> Failed to rename channel. Check bot permissions.'
  }
};

const t = (key, replacements = {}) => {
  const config = getConfig();
  const lang = config.language === 'en' ? 'en' : 'ar';
  let str = translations[lang][key] || key;
  Object.keys(replacements).forEach(k => {
    str = str.replace(new RegExp(`{${k}}`, 'g'), replacements[k]);
  });
  return str;
};

const getL = (key) => {
  const config = getConfig();
  const lang = config.language === 'en' ? 'en' : 'ar';
  return translations[lang][key] || key;
};

module.exports = { t, getL };
