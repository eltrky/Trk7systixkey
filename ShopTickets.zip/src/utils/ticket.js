const {
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  PermissionFlagsBits
} = require('discord.js');
const { run, get } = require('./db');
const { getConfig } = require('./configStore');

const getProductEmojis = () => {
  const config = getConfig();
  const emojis = {};
  if (config.products && Array.isArray(config.products)) {
    config.products.forEach(p => {
      emojis[p.name] = p.emoji.match(/^\d+$/) ? `<:${p.name.toLowerCase()}:${p.emoji}>` : p.emoji;
    });
  }
  return emojis;
};

const getPaymentEmojis = () => {
  const config = getConfig();
  const emojis = {};
  if (config.payments && Array.isArray(config.payments)) {
    config.payments.forEach(p => {
      emojis[p.name] = p.emoji.match(/^\d+$/) ? `<:${p.name.toLowerCase()}:${p.emoji}>` : p.emoji;
    });
  }
  return emojis;
};

const getTicketNumber = async () => {
  await run(`UPDATE counters SET sequence_value = sequence_value + 1 WHERE id = 'tickets'`);
  const row = await get(`SELECT sequence_value FROM counters WHERE id = 'tickets'`);
  return row.sequence_value.toString().padStart(4, '0');
};

const isStaffInteraction = (interaction, config) => {
  if (!interaction.guild) return false;
  const member = interaction.member;
  return member.roles.cache.has(config.sellerRoleId) || member.permissions.has(PermissionFlagsBits.Administrator);
};

const rebuildWelcomeContainer = (openerId, ticketNum, product, payment, showUnclaim, config) => {
  const productEmojis = getProductEmojis();
  const paymentEmojis = getPaymentEmojis();
  const productEmoji = productEmojis[product] || '';
  const paymentEmoji = paymentEmojis[payment] || '';
  const sellerMention = config.sellerRoleId ? `<@&${config.sellerRoleId}>` : '@sellers';

  const buttons = [
    showUnclaim
      ? new ButtonBuilder().setCustomId('ticket_unclaim').setLabel('Unclaim').setStyle(ButtonStyle.Secondary)
      : new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setStyle(ButtonStyle.Secondary)
  ];

  const welcomeTitleRaw = config.welcomeTitle || 'Order - #{ticketNum}';
  const welcomeTextRaw = config.welcomeText || 'مرحبا بك {user}';

  const welcomeTitle = welcomeTitleRaw.replace('{ticketNum}', ticketNum);
  const welcomeText = welcomeTextRaw.replace('{user}', `<@${openerId}>`);

  return new ContainerBuilder()
    .addMediaGalleryComponents(
      new MediaGalleryBuilder()
        .addItems(
          new MediaGalleryItemBuilder()
            .setURL(config.bannerUrl)
            .setDescription('Shop Banner')
        )
    )
    .addSeparatorComponents(new SeparatorBuilder())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`# ${welcomeTitle}`),
      new TextDisplayBuilder().setContent(welcomeText),
      new TextDisplayBuilder().setContent(`**Product: ${product} | ${productEmoji}**`),
      new TextDisplayBuilder().setContent(`**Payment: ${payment} | ${paymentEmoji}**`),
      new TextDisplayBuilder().setContent(`||${sellerMention}||`)
    )
    .addSeparatorComponents(new SeparatorBuilder())
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('ticket_config_menu')
          .setPlaceholder('Configuration Menu')
          .addOptions([
            { label: 'Add', value: 'ticket_opt_add' },
            { label: 'Remove', value: 'ticket_opt_remove' },
            { label: 'Rename', value: 'ticket_opt_rename' },
            { label: 'Come', value: 'ticket_opt_come' }
          ])
      )
    )
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(buttons)
    );
};

module.exports = { getTicketNumber, isStaffInteraction, rebuildWelcomeContainer };
