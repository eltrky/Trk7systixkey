const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../../config.json');

let liveConfig = {};

const loadConfig = () => {
  try {
    const raw = fs.readFileSync(configPath, 'utf8');
    liveConfig = JSON.parse(raw);
  } catch (error) {
    console.error(error);
  }
};

const getConfig = () => {
  return liveConfig;
};

const saveConfig = (newConfig) => {
  try {
    fs.writeFileSync(configPath, JSON.stringify(newConfig, null, 2), 'utf8');
    liveConfig = newConfig;
    return true;
  } catch (error) {
    console.error(error);
    return false;
  }
};

loadConfig();

module.exports = { getConfig, saveConfig, loadConfig };
