const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, AttachmentBuilder, MessageFlags } = require('discord.js');
const { rebuildWelcomeContainer, isStaffInteraction } = require('../utils/ticket');
const { run, get } = require('../utils/db');
const { t, getL } = require('../utils/lang');

const handleButtons = async (interaction, config, client) => {
  if (interaction.customId.startsWith('rate_')) {
    const [_, stars, product, openerId, channelId] = interaction.customId.split('_');

    try {
      await run(`UPDATE closed_tickets SET stars = ? WHERE channelId = ?`, [parseInt(stars, 10), channelId]);
    } catch (e) {
      console.error(e);
    }

    await interaction.update({
      content: t('ratingSuccess', { stars: '⭐'.repeat(parseInt(stars, 10)) }),
      components: []
    });

    const feedbackChannel = client.channels.cache.get(config.feedbackChannelId);
    if (feedbackChannel) {
      const starsString = '⭐'.repeat(parseInt(stars, 10));
      const feedbackFields = getL('feedbackEmbedFields');
      const feedbackEmbed = new EmbedBuilder()
        .setColor(0x8b5cf6)
        .setTitle(getL('feedbackEmbedTitle'))
        .addFields([
          { name: feedbackFields.client, value: `<@${openerId}>`, inline: true },
          { name: feedbackFields.product, value: `**${product}**`, inline: true },
          { name: feedbackFields.rating, value: `**${starsString}**`, inline: true }
        ])
        .setTimestamp();

      await feedbackChannel.send({ embeds: [feedbackEmbed] });
    }
    return;
  }

  if (interaction.customId === 'ticket_claim') {
    if (!isStaffInteraction(interaction, config)) {
      await interaction.reply({
        content: t('noPermission'),
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    let openerId, ticketNum, product, payment;
    const ticketDoc = await get(`SELECT * FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
    if (ticketDoc) {
      openerId = ticketDoc.openerId;
      ticketNum = ticketDoc.ticketNum;
      product = ticketDoc.product;
      payment = ticketDoc.payment;
      await run(`UPDATE tickets SET claimed = 1, claimedBy = ?, claimedAt = ? WHERE channelId = ?`, [interaction.user.id, Math.floor(Date.now() / 1000), interaction.channel.id]);
    } else {
      const parts = interaction.channel.topic ? interaction.channel.topic.split(',') : [];
      openerId = parts[0];
      ticketNum = parts[1];
      product = parts[2];
      payment = parts[3];
    }
    const updatedContainer = rebuildWelcomeContainer(openerId, ticketNum, product, payment, true, config);

    await interaction.update({
      components: [updatedContainer],
      flags: MessageFlags.IsComponentsV2
    });

    await interaction.followUp({
      content: t('claimedBy', { user: interaction.user.id })
    });
    return;
  }

  if (interaction.customId === 'ticket_unclaim') {
    if (!isStaffInteraction(interaction, config)) {
      await interaction.reply({
        content: t('noPermission'),
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    let openerId, ticketNum, product, payment;
    const ticketDoc = await get(`SELECT * FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
    if (ticketDoc) {
      openerId = ticketDoc.openerId;
      ticketNum = ticketDoc.ticketNum;
      product = ticketDoc.product;
      payment = ticketDoc.payment;
      await run(`UPDATE tickets SET claimed = 0, claimedBy = NULL, claimedAt = NULL WHERE channelId = ?`, [interaction.channel.id]);
    } else {
      const parts = interaction.channel.topic ? interaction.channel.topic.split(',') : [];
      openerId = parts[0];
      ticketNum = parts[1];
      product = parts[2];
      payment = parts[3];
    }
    const updatedContainer = rebuildWelcomeContainer(openerId, ticketNum, product, payment, false, config);

    await interaction.update({
      components: [updatedContainer],
      flags: MessageFlags.IsComponentsV2
    });

    await interaction.followUp({
      content: t('unclaimedBy', { user: interaction.user.id })
    });
    return;
  }

  if (interaction.customId === 'ticket_close') {
    if (!isStaffInteraction(interaction, config)) {
      await interaction.reply({
        content: t('noPermission'),
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    let openerId, ticketNum, product, payment, claimedBy, createdAt, claimedAt;
    const ticketDoc = await get(`SELECT * FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
    if (ticketDoc) {
      openerId = ticketDoc.openerId;
      ticketNum = ticketDoc.ticketNum;
      product = ticketDoc.product;
      payment = ticketDoc.payment;
      claimedBy = ticketDoc.claimedBy || 'Unclaimed';
      createdAt = ticketDoc.createdAt;
      claimedAt = ticketDoc.claimedAt;
    } else {
      const parts = interaction.channel.topic ? interaction.channel.topic.split(',') : [];
      openerId = parts[0];
      ticketNum = parts[1];
      product = parts[2];
      payment = parts[3];
      claimedBy = 'Unclaimed';
      createdAt = 0;
      claimedAt = null;
    }

    await interaction.reply({
      content: t('closingTicket')
    });

    setTimeout(async () => {
      try {
        const messages = await interaction.channel.messages.fetch({ limit: 100 });
        const messagesArray = Array.from(messages.values()).reverse();
        
        let messagesHtml = '';
        for (const msg of messagesArray) {
          const avatarUrl = msg.author.displayAvatarURL({ extension: 'png', size: 64 });
          messagesHtml += `
          <div class="message-container">
            <img class="avatar" src="${avatarUrl}" alt="avatar" />
            <div class="message-details">
              <div>
                <span class="author">${msg.author.tag}</span>
                <span class="timestamp">${msg.createdAt.toLocaleString()}</span>
              </div>
              <div class="content">${msg.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
            </div>
          </div>`;
        }

        const html = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <title>Transcript - ${interaction.channel.name}</title>
          <style>
            body { background-color: #36393f; color: #dcddde; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; padding: 20px; }
            .header { border-bottom: 1px solid #4f545c; padding-bottom: 20px; margin-bottom: 20px; }
            .title { color: #ffffff; margin: 0; font-size: 24px; }
            .meta { color: #72767d; margin-top: 5px; font-size: 14px; }
            .message-container { display: flex; margin-bottom: 16px; align-items: flex-start; }
            .avatar { width: 40px; height: 40px; border-radius: 50%; margin-right: 16px; object-fit: cover; }
            .message-details { display: flex; flex-direction: column; }
            .author { color: #ffffff; font-weight: 500; font-size: 16px; margin-right: 8px; }
            .timestamp { color: #72767d; font-size: 12px; }
            .content { margin-top: 4px; font-size: 15px; line-height: 1.4; white-space: pre-wrap; word-break: break-word; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1 class="title">Transcript: ${interaction.channel.name}</h1>
            <div class="meta">Generated on ${new Date().toLocaleString()} | Ticket Opener ID: ${openerId}</div>
          </div>
          ${messagesHtml}
        </body>
        </html>`;

        const buffer = Buffer.from(html, 'utf-8');
        const attachment = new AttachmentBuilder(buffer, { name: `transcript-${interaction.channel.name}.html` });

        const logChannel = client.channels.cache.get(config.logChannelId);
        if (logChannel) {
          const logFields = getL('logEmbedFields');
          const closedAt = Math.round(Date.now() / 1000);
          const isEn = config.language === 'en';

          let claimTimeStr = isEn ? 'Unclaimed (N/A)' : 'غير مستلمة (N/A)';
          if (claimedAt && createdAt) {
            const diff = claimedAt - createdAt;
            const mins = Math.floor(diff / 60);
            const secs = diff % 60;
            if (diff === 0) {
              claimTimeStr = isEn ? 'Instant' : 'فوري';
            } else {
              claimTimeStr = mins > 0 
                ? (isEn ? `${mins}m ${secs}s` : `${mins}د ${secs}ث`) 
                : (isEn ? `${secs}s` : `${secs}ث`);
            }
          }

          let totalTimeStr = isEn ? 'N/A' : 'غير محدد (N/A)';
          if (createdAt) {
            const diff = closedAt - createdAt;
            const hrs = Math.floor(diff / 3600);
            const mins = Math.floor((diff % 3600) / 60);
            const secs = diff % 60;
            if (hrs > 0) {
              totalTimeStr = isEn ? `${hrs}h ${mins}m ${secs}s` : `${hrs}س ${mins}د ${secs}ث`;
            } else {
              totalTimeStr = mins > 0 
                ? (isEn ? `${mins}m ${secs}s` : `${mins}د ${secs}ث`) 
                : (isEn ? `${secs}s` : `${secs}ث`);
            }
          }

          const claimVal = claimedBy && claimedBy !== 'Unclaimed' ? `<@${claimedBy}>` : (isEn ? 'Unclaimed (N/A)' : 'غير مستلمة (N/A)');

          const logEmbed = new EmbedBuilder()
            .setColor(0x8b5cf6)
            .setTitle(getL('logEmbedTitle'))
            .addFields([
              { name: logFields.num, value: `#${ticketNum}`, inline: true },
              { name: logFields.product, value: product, inline: true },
              { name: logFields.payment, value: payment, inline: true },
              { name: logFields.client, value: `<@${openerId}>`, inline: true },
              { name: logFields.claimedBy, value: claimVal, inline: true },
              { name: logFields.closedBy, value: `<@${interaction.user.id}>`, inline: true },
              { name: logFields.claimSpeed, value: claimTimeStr, inline: true },
              { name: logFields.totalDuration, value: totalTimeStr, inline: true },
              { name: logFields.closedAt, value: `<t:${closedAt}:F>`, inline: false }
            ])
            .setTimestamp()
            .setThumbnail(interaction.guild.iconURL({ extension: 'png', size: 128 }));

          await logChannel.send({ embeds: [logEmbed], files: [attachment] });
        }

        try {
          const opener = await client.users.fetch(openerId);
          const rateRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`rate_1_${product}_${openerId}_${interaction.channel.id}`).setLabel('⭐ 1').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`rate_2_${product}_${openerId}_${interaction.channel.id}`).setLabel('⭐ 2').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`rate_3_${product}_${openerId}_${interaction.channel.id}`).setLabel('⭐ 3').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`rate_4_${product}_${openerId}_${interaction.channel.id}`).setLabel('⭐ 4').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`rate_5_${product}_${openerId}_${interaction.channel.id}`).setLabel('⭐ 5').setStyle(ButtonStyle.Secondary)
          );
          await opener.send({
            content: t('ratingDM', { product }),
            components: [rateRow]
          });
        } catch (dmError) {
          console.error(dmError);
        }

        await run(
          `INSERT OR REPLACE INTO closed_tickets (channelId, openerId, ticketNum, product, payment, claimedBy, createdAt, claimedAt, closedAt, stars) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`,
          [interaction.channel.id, openerId, ticketNum, product, payment, claimedBy, createdAt, claimedAt, Math.floor(Date.now() / 1000)]
        );

        await run(`DELETE FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
        await interaction.channel.delete();
      } catch (error) {
        console.error(error);
      }
    }, 5000);
    return;
  }
};

module.exports = { handleButtons };
