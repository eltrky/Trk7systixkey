const {
  ContainerBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  SeparatorBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');
const { t, getL } = require('../utils/lang');
const { get } = require('../utils/db');
const { isStaffInteraction } = require('../utils/ticket');

const handleSetup = async (interaction, config) => {
  const options = [];
  if (config.products && Array.isArray(config.products)) {
    config.products.forEach(p => {
      const option = {
        label: p.name,
        value: `product_${p.name.toLowerCase()}`
      };
      if (p.emoji) {
        if (p.emoji.match(/^\d+$/)) {
          option.emoji = { id: p.emoji };
        } else {
          option.emoji = p.emoji;
        }
      }
      options.push(option);
    });
  }

  const container = new ContainerBuilder()
    .addMediaGalleryComponents(
      new MediaGalleryBuilder()
        .addItems(
          new MediaGalleryItemBuilder()
            .setURL(config.bannerUrl)
            .setDescription('Shop Banner')
        )
    )
    .addSeparatorComponents(new SeparatorBuilder())
    .addActionRowComponents(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('select_product')
          .setPlaceholder(getL('productsPlaceholder'))
          .addOptions(options)
      )
    );

  await interaction.reply({
    components: [container],
    flags: MessageFlags.IsComponentsV2
  });
};

const handleCome = async (interaction, config) => {
  if (!isStaffInteraction(interaction, config)) {
    await interaction.reply({
      content: t('noPermission'),
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  let openerId;
  const ticketDoc = await get(`SELECT openerId FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
  if (ticketDoc) {
    openerId = ticketDoc.openerId;
  } else {
    const parts = interaction.channel.topic ? interaction.channel.topic.split(',') : [];
    openerId = parts[0];
  }

  if (openerId) {
    await interaction.reply({
      content: t('comeWarn', { user: openerId })
    });
    try {
      const user = await interaction.client.users.fetch(openerId);
      const linkButton = new ButtonBuilder()
        .setLabel(t('goToTicket'))
        .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
        .setStyle(ButtonStyle.Link);
      const row = new ActionRowBuilder().addComponents(linkButton);
      const dmText = config.language === 'en'
        ? `⚠️ **Sorry For Disturbance, You've Been Requested To Come**\n\n🔹 **Requested In :** <#${interaction.channel.id}>\n🔹 **Requested By :** <@${interaction.user.id}>`
        : `⚠️ **نعتذر عن الإزعاج، يرجى حضورك للتذكرة**\n\n🔹 **الموقع :** <#${interaction.channel.id}>\n🔹 **بطلب من :** <@${interaction.user.id}>`;
      await user.send({
        content: dmText,
        components: [row]
      });
    } catch (dmError) {
      console.error(dmError);
    }
  } else {
    await interaction.reply({
      content: config.language === 'en' ? '❌ This command can only be used inside ticket channels!' : '❌ يمكن استخدام هذا الأمر داخل قنوات التذاكر فقط!',
      flags: MessageFlags.Ephemeral
    });
  }
};

const handleRename = async (interaction, config) => {
  if (!isStaffInteraction(interaction, config)) {
    await interaction.reply({
      content: t('noPermission'),
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const isTicket = interaction.channel.name.includes('-') || interaction.channel.topic;
  if (!isTicket) {
    await interaction.reply({
      content: config.language === 'en' ? '❌ This command can only be used inside ticket channels!' : '❌ يمكن استخدام هذا الأمر داخل قنوات التذاكر فقط!',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const newName = interaction.options.getString('name');
  try {
    await interaction.channel.setName(newName);
    await interaction.reply({
      content: t('modalRenameSuccess', { name: newName })
    });
  } catch (error) {
    console.error(error);
    await interaction.reply({
      content: t('modalRenameError'),
      flags: MessageFlags.Ephemeral
    });
  }
};

const handleBlacklist = async (interaction, config) => {
  if (!isStaffInteraction(interaction, config)) {
    await interaction.reply({
      content: t('noPermission'),
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  if (!config.blacklistRoleId) {
    await interaction.reply({
      content: config.language === 'en' ? '❌ Blacklist role is not configured in settings!' : '❌ لم يتم تحديد رتبة البلاك ليست في الإعدادات!',
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  const subcommand = interaction.options.getSubcommand();

  if (subcommand === 'add') {
    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      await interaction.reply({
        content: config.language === 'en' ? '❌ User not found in this server!' : '❌ العضو غير موجود في هذا السيرفر!',
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    try {
      await member.roles.add(config.blacklistRoleId);
      await interaction.reply({
        content: config.language === 'en' ? `✅ <@${user.id}> has been successfully added to the blacklist!` : `✅ تم إضافة <@${user.id}> إلى البلاك ليست بنجاح!`
      });
    } catch (e) {
      console.error(e);
      await interaction.reply({
        content: config.language === 'en' ? '❌ Failed to add user to blacklist. Check bot permissions!' : '❌ فشل إضافة العضو إلى البلاك ليست. تحقق من صلاحيات البوت!',
        flags: MessageFlags.Ephemeral
      });
    }
    return;
  }

  if (subcommand === 'remove') {
    const user = interaction.options.getUser('user');
    const member = await interaction.guild.members.fetch(user.id).catch(() => null);
    if (!member) {
      await interaction.reply({
        content: config.language === 'en' ? '❌ User not found in this server!' : '❌ العضو غير موجود في هذا السيرفر!',
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    try {
      await member.roles.remove(config.blacklistRoleId);
      await interaction.reply({
        content: config.language === 'en' ? `✅ <@${user.id}> has been successfully removed from the blacklist!` : `✅ تم إزالة <@${user.id}> من البلاك ليست بنجاح!`
      });
    } catch (e) {
      console.error(e);
      await interaction.reply({
        content: config.language === 'en' ? '❌ Failed to remove user from blacklist. Check bot permissions!' : '❌ فشل إزالة العضو من البلاك ليست. تحقق من صلاحيات البوت!',
        flags: MessageFlags.Ephemeral
      });
    }
    return;
  }

  if (subcommand === 'list') {
    try {
      const role = await interaction.guild.roles.fetch(config.blacklistRoleId).catch(() => null);
      if (!role) {
        await interaction.reply({
          content: config.language === 'en' ? '❌ Blacklist role not found in this server!' : '❌ لم يتم العثور على رتبة البلاك ليست في هذا السيرفر!',
          flags: MessageFlags.Ephemeral
        });
        return;
      }

      const members = role.members;
      if (members.size === 0) {
        await interaction.reply({
          content: config.language === 'en' ? 'ℹ️ The blacklist is currently empty.' : 'ℹ️ قائمة البلاك ليست فارغة حالياً.'
        });
        return;
      }

      const embed = new EmbedBuilder()
        .setColor(0x8b5cf6)
        .setTitle(config.language === 'en' ? '🚫 Blacklisted Users' : '🚫 الأعضاء المحظورين (البلاك ليست)')
        .setDescription(members.map(m => `• <@${m.user.id}> (ID: \`${m.user.id}\`)`).join('\n'))
        .setTimestamp();

      await interaction.reply({ embeds: [embed] });
    } catch (e) {
      console.error(e);
      await interaction.reply({
        content: config.language === 'en' ? '❌ Failed to fetch blacklist members list!' : '❌ فشل جلب قائمة أعضاء البلاك ليست!',
        flags: MessageFlags.Ephemeral
      });
    }
  }
};

module.exports = {
  handleSetup,
  handleCome,
  handleRename,
  handleBlacklist
};
