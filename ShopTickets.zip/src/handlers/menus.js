const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  MessageFlags,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const { getTicketNumber, rebuildWelcomeContainer, isStaffInteraction } = require('../utils/ticket');
const { run, get } = require('../utils/db');
const { t, getL } = require('../utils/lang');

const handleMenus = async (interaction, config) => {
  if (config.blacklistRoleId && config.blacklistRoleId !== config.guildId && interaction.member && interaction.member.roles.cache.has(config.blacklistRoleId)) {
    await interaction.reply({
      content: t('blacklistWarn'),
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  if (interaction.customId === 'select_product') {
    const selectedValue = interaction.values[0];
    const productName = selectedValue.replace('product_', '');
    const matchedProduct = config.products ? config.products.find(p => p.name.toLowerCase() === productName.toLowerCase()) : null;
    const friendlyName = matchedProduct ? matchedProduct.name : (productName.charAt(0).toUpperCase() + productName.slice(1));

    const options = [];
    if (config.payments && Array.isArray(config.payments)) {
      config.payments.forEach(p => {
        const option = {
          label: p.name,
          value: p.name
        };
        if (p.emoji) {
          if (p.emoji.match(/^\d+$/)) {
            option.emoji = { id: p.emoji };
          } else {
            option.emoji = p.emoji;
          }
        }
        options.push(option);
      });
    }

    await interaction.update({
      components: interaction.message.components
    });

    await interaction.followUp({
      content: config.language === 'en'
        ? `Product Selected: **${friendlyName}**\n\n**Select Payment Method**`
        : `تم اختيار المنتج : **${friendlyName}**\n\n**اختر طريقة الدفع**`,
      components: [
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`select_payment_${friendlyName}`)
            .setPlaceholder(config.language === 'en' ? 'Select Payment Method' : 'الرجاء اختيار طريقة الدفع')
            .addOptions(options)
        )
      ],
      flags: MessageFlags.Ephemeral
    });
    return;
  }

  if (interaction.customId.startsWith('select_payment_')) {
    const product = interaction.customId.replace('select_payment_', '');
    const payment = interaction.values[0];

    await interaction.reply({
      content: t('loading'),
      flags: MessageFlags.Ephemeral
    });

    let categoryId = null;
    if (config.products && Array.isArray(config.products)) {
      const match = config.products.find(p => p.name.toLowerCase() === product.toLowerCase());
      if (match) {
        categoryId = match.categoryId;
      }
    }

    const guild = interaction.guild;

    if (!guild) return;

    let parentId = categoryId;
    if (categoryId) {
      const categoryChannel = guild.channels.cache.get(categoryId) || await guild.channels.fetch(categoryId).catch(() => null);
      if (!categoryChannel || categoryChannel.type !== ChannelType.GuildCategory) {
        parentId = null;
      }
    } else {
      parentId = null;
    }

    try {
      const ticketNum = await getTicketNumber();
      const channel = await guild.channels.create({
        name: `${product.toLowerCase()}-${ticketNum}`,
        type: ChannelType.GuildText,
        parent: parentId || null,
        topic: `${interaction.user.id},${ticketNum},${product},${payment}`,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel]
          },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          },
          {
            id: config.sellerRoleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory
            ]
          }
        ]
      });

      if (config.clientRoleId) {
        try {
          const member = interaction.member || await guild.members.fetch(interaction.user.id).catch(() => null);
          if (member && member.roles) {
            await member.roles.add(config.clientRoleId).catch(() => null);
          }
        } catch (roleError) {
          console.error(roleError);
        }
      }

      const ticketButton = new ButtonBuilder()
        .setLabel(getL('goToTicket'))
        .setStyle(ButtonStyle.Link)
        .setURL(`https://discord.com/channels/${guild.id}/${channel.id}`);

      const buttonRow = new ActionRowBuilder().addComponents(ticketButton);

      await interaction.editReply({
        content: t('ticketCreated'),
        components: [buttonRow]
      });

      const welcomeContainer = rebuildWelcomeContainer(interaction.user.id, ticketNum, product, payment, false, config);

      await channel.send({
        components: [welcomeContainer],
        flags: MessageFlags.IsComponentsV2
      });

      await run(
        `INSERT OR REPLACE INTO tickets (channelId, openerId, ticketNum, product, payment, claimed, claimedBy, createdAt, claimedAt) VALUES (?, ?, ?, ?, ?, 0, NULL, ?, NULL)`,
        [channel.id, interaction.user.id, ticketNum, product, payment, Math.floor(Date.now() / 1000)]
      );
    } catch (error) {
      console.error(error);
      await interaction.editReply({
        content: '<:Warn:1510598267715715102> **حدث خطأ أثناء إنشاء التذكرة. الرجاء المحاولة مرة أخرى.**'
      });
    }
    return;
  }

  if (interaction.customId === 'ticket_config_menu') {
    if (!isStaffInteraction(interaction, config)) {
      await interaction.reply({
        content: t('noPermission'),
        flags: MessageFlags.Ephemeral
      });
      return;
    }

    const option = interaction.values[0];

    if (option === 'ticket_opt_add') {
      const modal = new ModalBuilder()
        .setCustomId('modal_add_user')
        .setTitle(getL('modalAddTitle'));

      const userIdInput = new TextInputBuilder()
        .setCustomId('user_id')
        .setLabel(getL('modalAddLabel'))
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('123456789012345678');

      modal.addComponents(new ActionRowBuilder().addComponents(userIdInput));
      await interaction.showModal(modal);
      return;
    }

    if (option === 'ticket_opt_remove') {
      const modal = new ModalBuilder()
        .setCustomId('modal_remove_user')
        .setTitle(getL('modalRemoveTitle'));

      const userIdInput = new TextInputBuilder()
        .setCustomId('user_id')
        .setLabel(getL('modalRemoveLabel'))
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('123456789012345678');

      modal.addComponents(new ActionRowBuilder().addComponents(userIdInput));
      await interaction.showModal(modal);
      return;
    }

    if (option === 'ticket_opt_rename') {
      const modal = new ModalBuilder()
        .setCustomId('modal_rename_channel')
        .setTitle(getL('modalRenameTitle'));

      const nameInput = new TextInputBuilder()
        .setCustomId('new_name')
        .setLabel(getL('modalRenameLabel'))
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setPlaceholder('robux-vip');

      modal.addComponents(new ActionRowBuilder().addComponents(nameInput));
      await interaction.showModal(modal);
      return;
    }

    if (option === 'ticket_opt_come') {
      let openerId;
      const ticketDoc = await get(`SELECT openerId FROM tickets WHERE channelId = ?`, [interaction.channel.id]);
      if (ticketDoc) {
        openerId = ticketDoc.openerId;
      } else {
        const parts = interaction.channel.topic ? interaction.channel.topic.split(',') : [];
        openerId = parts[0];
      }
      if (openerId) {
        await interaction.reply({
          content: t('comeWarn', { user: openerId })
        });
        try {
          const user = await interaction.client.users.fetch(openerId);
          const linkButton = new ButtonBuilder()
            .setLabel(t('goToTicket'))
            .setURL(`https://discord.com/channels/${interaction.guild.id}/${interaction.channel.id}`)
            .setStyle(ButtonStyle.Link);
          const row = new ActionRowBuilder().addComponents(linkButton);
          const dmText = config.language === 'en'
            ? `⚠️ **Sorry For Disturbance, You've Been Requested To Come**\n\n🔹 **Requested In :** <#${interaction.channel.id}>\n🔹 **Requested By :** <@${interaction.user.id}>`
            : `⚠️ **نعتذر عن الإزعاج، يرجى حضورك للتذكرة**\n\n🔹 **الموقع :** <#${interaction.channel.id}>\n🔹 **بطلب من :** <@${interaction.user.id}>`;
          await user.send({
            content: dmText,
            components: [row]
          });
        } catch (dmError) {
          console.error(dmError);
        }
      } else {
        await interaction.reply({
          content: t('comeError'),
          flags: MessageFlags.Ephemeral
        });
      }
      return;
    }
  }
};

module.exports = { handleMenus };
