const { MessageFlags } = require('discord.js');
const { t } = require('../utils/lang');

const handleModals = async (interaction, config) => {
  if (interaction.customId === 'modal_add_user') {
    const userId = interaction.fields.getTextInputValue('user_id');
    try {
      await interaction.channel.permissionOverwrites.create(userId, {
        ViewChannel: true,
        SendMessages: true,
        ReadMessageHistory: true
      });
      await interaction.reply({
        content: t('modalAddSuccess', { user: userId })
      });
    } catch (error) {
      await interaction.reply({
        content: t('modalAddError'),
        flags: MessageFlags.Ephemeral
      });
    }
    return;
  }

  if (interaction.customId === 'modal_remove_user') {
    const userId = interaction.fields.getTextInputValue('user_id');
    try {
      await interaction.channel.permissionOverwrites.delete(userId);
      await interaction.reply({
        content: t('modalRemoveSuccess', { user: userId })
      });
    } catch (error) {
      await interaction.reply({
        content: t('modalRemoveError'),
        flags: MessageFlags.Ephemeral
      });
    }
    return;
  }

  if (interaction.customId === 'modal_rename_channel') {
    const newName = interaction.fields.getTextInputValue('new_name');
    try {
      await interaction.channel.setName(newName.toLowerCase());
      await interaction.reply({
        content: t('modalRenameSuccess', { name: newName.toLowerCase() })
      });
    } catch (error) {
      await interaction.reply({
        content: t('modalRenameError'),
        flags: MessageFlags.Ephemeral
      });
    }
    return;
  }
};

module.exports = { handleModals };
